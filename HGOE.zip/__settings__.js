ASSET_PREFIX = "";
SCRIPT_PREFIX = "";
SCENE_PATH = "1486069.json";
CONTEXT_OPTIONS = {
    'antialias': true,
    'alpha': false,
    'preserveDrawingBuffer': false,
    'preferWebGl2': true,
    'powerPreference': "high-performance"
};
SCRIPTS = [ 95475238, 95475260, 95484383, 95533143, 95544738, 95558863, 95558915, 95563938, 95563990, 95734558, 95736454, 95961149, 98261208, 98261209, 98261210 ];
CONFIG_FILENAME = "config.json";
INPUT_SETTINGS = {
    useKeyboard: true,
    useMouse: true,
    useGamepads: false,
    useTouch: true
};
pc.script.legacy = false;
PRELOAD_MODULES = [
];
