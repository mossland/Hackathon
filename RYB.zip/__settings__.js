ASSET_PREFIX = "";
SCRIPT_PREFIX = "";
SCENE_PATH = "1497393.json";
CONTEXT_OPTIONS = {
    'antialias': true,
    'alpha': false,
    'preserveDrawingBuffer': false,
    'preferWebGl2': true,
    'powerPreference': "high-performance"
};
SCRIPTS = [ 97099476, 97099481, 97099480, 97099455, 97099490, 97099484, 97099489, 97099463, 97099471, 97099454, 97099456, 97099467, 97112558, 97454502, 98411829, 98411830, 98411831 ];
CONFIG_FILENAME = "config.json";
INPUT_SETTINGS = {
    useKeyboard: true,
    useMouse: true,
    useGamepads: false,
    useTouch: true
};
pc.script.legacy = false;
PRELOAD_MODULES = [
];
