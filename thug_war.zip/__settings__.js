ASSET_PREFIX = "";
SCRIPT_PREFIX = "";
SCENE_PATH = "1471300.json";
CONTEXT_OPTIONS = {
    'antialias': true,
    'alpha': false,
    'preserveDrawingBuffer': false,
    'preferWebGl2': true,
    'powerPreference': "high-performance"
};
SCRIPTS = [ 93486037, 93611369, 93612872, 93615538, 93618639, 93618849, 93620883, 93622713, 93628355, 93864332, 93868454, 93874119, 94242644, 94250892, 94267265, 97847696, 97880896, 97881306 ];
CONFIG_FILENAME = "config.json";
INPUT_SETTINGS = {
    useKeyboard: true,
    useMouse: true,
    useGamepads: false,
    useTouch: true
};
pc.script.legacy = false;
PRELOAD_MODULES = [
];
