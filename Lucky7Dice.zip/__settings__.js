ASSET_PREFIX = "";
SCRIPT_PREFIX = "";
SCENE_PATH = "1495189.json";
CONTEXT_OPTIONS = {
    'antialias': true,
    'alpha': false,
    'preserveDrawingBuffer': false,
    'preferWebGl2': true,
    'powerPreference': "high-performance"
};
SCRIPTS = [ 96690117, 96690120, 96690106, 96690133, 96690128, 96690109, 96690136, 96690123, 96690107, 96690122, 96690126, 96690113, 98276937, 98276938, 98276939 ];
CONFIG_FILENAME = "config.json";
INPUT_SETTINGS = {
    useKeyboard: true,
    useMouse: true,
    useGamepads: false,
    useTouch: true
};
pc.script.legacy = false;
PRELOAD_MODULES = [
];
